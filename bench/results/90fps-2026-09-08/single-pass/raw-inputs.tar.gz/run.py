import subprocess,csv,json
from pathlib import Path
root=Path(__file__).parent
adb='/home/nerdrx/.local/bin/adb'
base='cd /data/local/tmp/planar-90 && NX_PLANAR_QUEUE_PRIORITY=high NX_PLANAR_TILE=1 NX_PLANAR_PACE_FPS=90 NX_PLANAR_SPIN=1 NX_PLANAR_REUSE_COMMANDS=1 '
for name,extra in [('full-a',''),('multi-a','NX_PLANAR_FOVEATED=1 '),('single-a','NX_PLANAR_FOVEATED=1 NX_PLANAR_FOVEATED_SINGLE_PASS=1 '),('single-b','NX_PLANAR_FOVEATED=1 NX_PLANAR_FOVEATED_SINGLE_PASS=1 '),('multi-b','NX_PLANAR_FOVEATED=1 '),('full-b','')]:
 with (root/(name+'.csv')).open('w') as out,(root/(name+'.log')).open('w') as err:
  subprocess.run([adb,'shell',base+extra+'taskset 80 ./nx-planar-single camera90.nxv . 720'],stdout=out,stderr=err,check=True,timeout=60)
 rows=list(csv.DictReader((root/(name+'.csv')).open()))
 assert len(rows)==720
 print(name,'misses',sum(float(r['total_ms'])>1000/90 for r in rows),'maxage',max(int(r['peripheral_age_max']) for r in rows),flush=True)
