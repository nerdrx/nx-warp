#version 450
layout(std430, binding = 1) readonly buffer Records { uint records[]; };
layout(push_constant) uniform PC { int frameQP; int chromaQPOffset; int width; int height; } pc;
layout(location = 0) flat out vec4 cellColor;
vec4 rgba8(uint x) { return vec4(float(x & 255u), float((x >> 8u) & 255u), float((x >> 16u) & 255u), float(x >> 24u)) / 255.0; }
void main() {
    uint tilesX = (uint(pc.width) + 63u) / 64u;
    uint inst = uint(gl_InstanceIndex), tile = inst >> 6u, cell = inst & 63u;
    uint tx = tile % tilesX, ty = tile / tilesX, cx = cell & 7u, cy = cell >> 3u;
    vec2 corner = vec2((gl_VertexIndex == 1 || gl_VertexIndex == 4 || gl_VertexIndex == 5) ? 1.0 : 0.0,
                       (gl_VertexIndex == 2 || gl_VertexIndex == 3 || gl_VertexIndex == 5) ? 1.0 : 0.0);
    vec2 pixel = vec2(tx * 64u + cx * 8u, ty * 64u + cy * 8u) + corner * 8.0;
    gl_Position = vec4(pixel / vec2(float(pc.width), float(pc.height)) * 2.0 - 1.0, 0.0, 1.0);
    uint base = tile * 4u, map = cell < 32u ? records[base] : records[base + 1u];
    uint label = (map >> (cell & 31u)) & 1u;
    cellColor = rgba8(records[base + 2u + label]);
}
